This is a project initiated by Sir Noodles.
The idea came to me when my evil python teacher gave us an asignement about matrices.
The project aims at computing matrices. For now it can only do additions.
To use it, just put your matrices in the MatrixGrid.csv file, you can you excell for that, make sure to separate them by underscores (_) and just run the program, the resulting matrix will appear in the MatrixResult.csv.
There is still more to come:
-The user experience is pretty awfull so building an UI wiht Tkinter would be great
-It would be great if the program could also do matrix multiplication and other matrix operations
-We would also like to allow users to use this program to do matrix operations with at least 3 dimensional matrices.